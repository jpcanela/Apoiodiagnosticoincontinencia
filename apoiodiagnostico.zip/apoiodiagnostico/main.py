from flask import Flask, request, jsonify, render_template
import openai
import os
import json

# Configuração da API OpenAI
api_key = os.getenv("OPENAI_API_KEY")
if not api_key:
    raise ValueError("API Key da OpenAI não configurada. Verifique em Secrets.")

# Inicializando o cliente OpenAI
client = openai.OpenAI(api_key=api_key)

# Inicializando o Flask
app = Flask(__name__)

# Carregar os pesos do arquivo JSON
def carregar_pesos():
    try:
        with open("pesos.json", "r") as file:
            return json.load(file)
    except FileNotFoundError:
        raise FileNotFoundError("O arquivo 'pesos.json' não foi encontrado.")
    except json.JSONDecodeError:
        raise ValueError("Erro ao decodificar o arquivo 'pesos.json'. Verifique o formato.")

# Rota para o frontend
@app.route("/")
def home():
    return render_template("index.html")

# Rota para processar os inputs
@app.route("/process", methods=["POST"])
def process():
    data = request.get_json()

    if not data:
        return jsonify({'error': 'Nenhum dado recebido'}), 400

    # Carregar pesos atualizados
    try:
        pesos = carregar_pesos()
    except Exception as e:
        return jsonify({'error': str(e)}), 500

    # Inicializando o score
    score = 0
    score_total = 0

    # Calcular o score com base nos nós e arestas
    for key, valores in pesos.items():
        resposta = data.get(key, "Indeterminado")
        peso_no = valores.get("peso_no", 0)
        peso_aresta = valores.get("peso_aresta", 0)

        if resposta == "Sim":
            score += peso_no
            score_total += peso_no + peso_aresta
        elif resposta == "Indeterminado":
            score_total += peso_no + peso_aresta

    # Normalizar o score
    score = round(score / score_total, 2) if score_total > 0 else 0

    # Classificação do diagnóstico
    diagnosticos = []
    if score >= 0.7:
        diagnosticos.append("incontinência urinária por transbordamento")
    if 0.5 <= score < 0.7:
        diagnosticos.append("incontinência urinária de urgência")
    if 0.3 <= score < 0.5:
        diagnosticos.append("incontinência urinária de esforço")
    if score < 0.3:
        diagnosticos.append("incontinência urinária funcional")

    diagnostico = " / ".join(diagnosticos)

    # Solicitar ao GPT-3.5
    try:
        prompt = (
            f"Paciente com os seguintes sinais e sintomas: {data}. "
            "Identifique o tipo de incontinência urinária (esforço, urgência, transbordamento ou funcional), "
            "possíveis causas, conduta diagnóstica e tratamento. Responda de forma objetiva em até 20 linhas."
        )

        response = client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "Você é um assistente médico especializado em diagnósticos clínicos."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=400
        )

        hipoteses = response.choices[0].message.content.strip()

    except openai.OpenAIError as e:
        hipoteses = f"Erro ao gerar hipóteses: {str(e)}"

    return jsonify({
        'score': score,
        'diagnostico': f"Probabilidade de {diagnostico}",
        'hipoteses': hipoteses
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=80, debug=True)

